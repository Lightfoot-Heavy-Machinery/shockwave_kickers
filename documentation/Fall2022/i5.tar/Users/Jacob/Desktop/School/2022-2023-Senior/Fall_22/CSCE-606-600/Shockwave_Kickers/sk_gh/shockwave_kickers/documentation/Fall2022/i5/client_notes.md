* Looking forward to having a useable version early next week
* Would like documention for setting up both local and deployed instances from the ground up
* He will send us CSV information soon to ensure the headers match

