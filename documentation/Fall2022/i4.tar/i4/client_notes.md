* Increase quiz choices/possible answers
* Current Score not updating on incorrect answer in production
* Have a way to search for student on email -> important use case!
